# DAWI-Sesion01Inicio 
### Registro en una tabla mediante JPA

## Autor ✒️

* **Jorge Jacinto ** - [jorgejacinto9701](https://github.com/jorgejacinto9701)