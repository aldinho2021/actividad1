package com.empresa.service;

import com.empresa.entity.Medicamento;

public interface MedicamentoService {

	public Medicamento insertaMedicamento(Medicamento obj);
}
