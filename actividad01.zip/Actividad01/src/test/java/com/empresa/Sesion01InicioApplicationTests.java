package com.empresa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Sesion01InicioApplicationTests {

	@Test
	void contextLoads() {
	}

}
